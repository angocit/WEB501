import './App.css'
import { Route, Routes } from 'react-router-dom'

function App() {
  return (
    <>
    <h1>Base WEB501</h1>
    <Routes>
      
    </Routes>
    </>
  )
}
export default App
